---
name: Profil RPL SMK Nusantara Teknologi
colors:
  surface: '#f8f9ff'
  surface-dim: '#d0dbed'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e6eeff'
  surface-container-high: '#dee9fc'
  surface-container-highest: '#d9e3f6'
  on-surface: '#121c2a'
  on-surface-variant: '#504533'
  inverse-surface: '#27313f'
  inverse-on-surface: '#eaf1ff'
  outline: '#827560'
  outline-variant: '#d4c4ac'
  surface-tint: '#7b5900'
  primary: '#7b5900'
  on-primary: '#ffffff'
  primary-container: '#f5b400'
  on-primary-container: '#654900'
  inverse-primary: '#fdbb12'
  secondary: '#3a608e'
  on-secondary: '#ffffff'
  secondary-container: '#a4c9fd'
  on-secondary-container: '#2d5481'
  tertiary: '#3f608a'
  on-tertiary: '#ffffff'
  tertiary-container: '#a0c1f1'
  on-tertiary-container: '#2d4f78'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdea4'
  primary-fixed-dim: '#fdbb12'
  on-primary-fixed: '#261900'
  on-primary-fixed-variant: '#5d4200'
  secondary-fixed: '#d3e4ff'
  secondary-fixed-dim: '#a4c9fd'
  on-secondary-fixed: '#001c38'
  on-secondary-fixed-variant: '#1f4875'
  tertiary-fixed: '#d3e3ff'
  tertiary-fixed-dim: '#a8c9f9'
  on-tertiary-fixed: '#001c39'
  on-tertiary-fixed-variant: '#254871'
  background: '#f8f9ff'
  on-background: '#121c2a'
  surface-variant: '#d9e3f6'
typography:
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28.8px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  label-sm:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  caption:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-sm: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-2xl: 5rem
---

## Brand & Style

The design system establishes an institutional, authoritative, and disciplined visual environment tailored for the Software Engineering Department (Rekayasa Perangkat Lunak - RPL) at SMK Nusantara Teknologi. It balances the formal governance of an accredited Indonesian vocational technical institution with the precision of an engineering laboratory.

The style operates under an institutional-technical philosophy: flat, high-density, sharp-edged, and disciplined. Visual weight is communicated through solid color blocking, deliberate borders, and structured hierarchy rather than decorative ornamentation. The interface deliberately avoids decorative gradients, glowing effects, and organic radii, reinforcing an ethos of architectural rigor, standard-compliant coding, and educational professionalism.

## Colors

The palette utilizes a dominant technical Navy structure anchored by purposeful Gold indicators.

- **Primary Accent (`#F5B400`)**: Used for high-priority interactive calls to action, dynamic states, active navigational markers, badge highlights, and structural section underlines. Hover state defaults to `#D99E00`.
- **Secondary (`#0B3A66`)**: The primary institutional color. Governs the primary tier of navigation, high-contrast hero modules, statistical summary bands, dark container footers, and persistent floating points.
- **Tertiary (`#08325A`)**: The deep anchor tone. Used for tier-2 navigation bars, dark card headers, active list groups, and subtle structural frame contrasts.
- **Neutral Primary (`#1F2937`)**: The default reading token for high-legibility body copy and form labels.
- **Neutral Light (`#F8F8F8`)**: Background surface applied to secondary content sections, table zebra striping, and inset system panels.
- **Surface Pure (`#FFFFFF`)**: Base canvas for primary reading materials, white cards, and editable elements.
- **System Borders (`#E5E7EB`)**: Structural 1px separation lines across all modular components.
- **Feedback Alerts**: `#DC2626` strictly for form invalidation/errors; `#16A34A` for successful validation, active build flags, and status confirmations.

## Typography

The type scale combines `Space Grotesk` for headlines and `Hanken Grotesk` for operational body copy and navigational metadata.

- **Headlines (`Space Grotesk`)**: Provides an overt technical, engineering-grade clarity. Used for page titles, module framing, and data-dense dashboards.
  - Section headers (`headline-lg`) must consistently be styled with an anchored decorative horizontal bar underneath: 64px width, 3px height, colored in `#F5B400` with an 8px top margin.
- **Body & Controls (`Hanken Grotesk`)**: Ensures maximum readability across long-form curriculum descriptions, specification tables, and form controls. Set with a generous line-height of 1.6 on lead paragraphs (`body-lg`) to balance information density.

## Layout & Spacing

The system is constructed around an 8px technical layout grid within a 12-column fluid framework, capped at a centered maximum width of 1200px.

- **Canvas Limits**: Content remains tightly aligned within `max-w-[1200px]`.
- **Vertical Hierarchy**: Major educational domains and thematic sections are demarcated with `space-2xl` (80px / 5rem) vertical spacing. Secondary module clusters within a section use `space-xl` (40px / 2.5rem).
- **Responsive Adaptation**:
  - **Desktop (1024px+)**: 12 columns, 24px (`1.5rem`) gutter, 80px section spacing.
  - **Tablet (768px - 1023px)**: 8 columns, 16px (`1rem`) gutter, 48px section spacing.
  - **Mobile (< 768px)**: 4 columns, 16px (`1rem`) gutter, 32px section spacing, outer margin reduced to `1rem`. Structural rows stack sequentially into single-column cards.

## Elevation & Depth

Visual hierarchy is maintained almost exclusively through flat boundaries, high-contrast architectural framing, and solid surface tones. 

- **Surface Tiers**: Surface layering relies on contrast between `#FFFFFF` and `#F8F8F8`. Insets, table heads, and form groups use the alternate neutral background rather than drop shadows.
- **Borders**: All cards, structural tiles, inputs, and interactive boundaries utilize a deliberate, flat 1px solid border (`#E5E7EB`).
- **Interactive Depth**: Elevation through drop shadow is reserved exclusively for interactive hovering states. When cards or actionable elements are focused or hovered, apply a localized navy shadow: `box-shadow: 0 4px 12px rgba(11, 58, 102, 0.15)`. No ambient shadows are permitted in static default states.

## Shapes

The interface implements a strict `0` (Sharp) corner profile. Every container, button, form input, badge, tag, and modal edge terminates in a razor-sharp 90-degree corner. 

This reinforces structural order, code-like precision, and structural engineering aesthetics across all school department components.

## Components

### Buttons
- **Primary CTA**: `#F5B400` background, `#1F2937` label, 0px border-radius, font weight 600, padding 12px 24px. Hover state changes background to `#D99E00` with subtle elevation `0 4px 12px rgba(11, 58, 102, 0.15)`.
- **Secondary / Outline**: Transparent background, 1px solid `#0B3A66`, text color `#0B3A66`. Hover state fills with `#0B3A66` and text switches to `#FFFFFF`.
- **Floating Communication Button**: Persistent at bottom-left, fixed 64px x 64px square container, background `#0B3A66`, icon in white. Displays a high-contrast accent indicator on hover.

### Navigation Header
- **Tier 1 (Utility Bar)**: Background `#0B3A66`, height 40px, containing school identity, portal link, and academic year indicator. Text in white, 14px.
- **Tier 2 (Primary Navigation)**: Background `#08325A`, sticky positioning. Nav links 16px semibold white. Active state marked by a solid bottom border in `#F5B400` (3px thickness) and gold text color.

### Teacher Profile Cards
- Sharp 1px solid `#E5E7EB` outline on `#FFFFFF` base. Top image block with an aspect ratio of 1:1 or 4:3, strictly cropped without borders. Information panel contains name (`Space Grotesk`, 18px), specialization badge, and educational credentials. Applies the hover elevation shadow on mouseenter.

### Curriculum Semester Tabs & Lists
- Segmented rectangular tab list with 0px radius. Inactive tab: `#F8F8F8` background, `#1F2937` text, 1px border `#E5E7EB`. Active tab: `#0B3A66` background, `#FFFFFF` text, bold weight.
- Semester content displays tabular specifications with `#F8F8F8` alternating zebra rows, 12px padding, and 1px bottom border on list items.

### Filter Chips
- Monospaced/technical appearance. Sharp 1px border. Inactive: `#FFFFFF` fill, `#1F2937` text. Active: `#0B3A66` fill, `#FFFFFF` text, border `#0B3A66`.

### Form Controls & Validation
- Text fields, selects, and textareas: 0px border-radius, 1px solid `#E5E7EB`, padding 12px 16px, background `#FFFFFF`. Active focus changes border to 1px solid `#0B3A66`.
- Error state: 1px solid `#DC2626` with red validation microcopy positioned 4px below the input.
- Checkboxes & Radios: Square geometric frames with 0px radius. Checked state uses solid `#0B3A66` background with a white square core mark.

### Footer
- 3-column structured grid over `#0B3A66` background with `#08325A` sub-footer copyright row. Headings in `#F5B400`, body links in `#FFFFFF` with 80% opacity, shifting to 100% opacity and gold underline on hover.